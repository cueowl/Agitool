﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AgiSoft.Models;

namespace AgiSoft.Controllers {
    public class ProjectController : Controller {
        private AgiSoftDb db = new AgiSoftDb();
        //
        // GET: /Project/

        public ActionResult Index() {
            return View();
        }

        // GET: /Project/Projects
        public ActionResult Projects() {
            return View(db.Projects.ToList());
        }

        // GET: /Admin/RolesDetails
        public ActionResult ProjectsDetails(int id = 0) {
            Projects projects = db.Projects.Find(id);

            if (projects == null) {
                return HttpNotFound();
            }
            if (projects != null) {
                ViewBag.Type = "project";
            }

            return View(projects);
        }

        // GET: /Project/ProjectsCreate
        public ActionResult ProjectsCreate() {
            Projects model = new Models.Projects();

            var teamitem = from p in db.Teams
                           select p;

            TeamOnProject modelteam = new TeamOnProject();
            List<Teams> team = new List<Teams>();

            Teams team1 = new Teams() { TeamId = 0, TeamName = "--Select--" };
            team.Add(team1);
            foreach (var item1 in teamitem) {
                team1 = new Teams() { TeamId = item1.TeamId, TeamName = item1.TeamName };
                team.Add(team1);
            }

            ViewBag.teamId = new SelectList(team, "TeamId", "TeamName", modelteam.TeamId);

            var item = from p in db.UserProfiles
                       select p;

            List<UserProfile> managers = new List<UserProfile>();

            UserProfile user = new UserProfile() { UserId = 0, UserName = "--Select--" };
            managers.Add(user);
            foreach (var item1 in item) {
                user = new UserProfile() { UserId = item1.UserId, UserName = item1.UserName };
                managers.Add(user);
            }

            ViewBag.ManagerId = new SelectList(managers, "UserId", "UserName", model.ManagerId);

            var statusid = (from CodeSet pt in db.CodeSet
                            join CodeSetType p in db.CodeSetType on pt.CodeSetTypeId equals p.CodeSetTypeId into temp
                            from p in temp.DefaultIfEmpty()
                            where p.CodeSetTypeDesc == "ProjectType"
                            select new { pt.CodeSetDesc, pt.CodeSetId }).ToList();

            List<CodeSet> codeset = new List<CodeSet>();
            CodeSet codeset1 = new CodeSet() { CodeSetId = 0, CodeSetDesc = "--Select--" };
            codeset.Add(codeset1);
            foreach (var item2 in statusid) {
                codeset1 = new CodeSet() { CodeSetId = item2.CodeSetId, CodeSetDesc = item2.CodeSetDesc.ToString() };
                codeset.Add(codeset1);
            }

            ViewBag.Status = new SelectList(codeset, "CodeSetId", "CodeSetDesc", model.Status);
            ViewBag.ManagerId = new SelectList(managers, "UserId", "UserName", model.ManagerId);

            return View(model);
        }

        // POST: /Project/ProjectsCreate/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProjectsCreate(Projects project) {
            if (ModelState.IsValid) {
                project.SettingId = 0;
                db.Projects.Add(project);
                db.SaveChanges();

                return RedirectToAction("Projects");
            }
            return View(project);
        }

        // GET: /Project/ProjectsEdit
        public ActionResult ProjectsEdit(int id) {
            Projects projects = db.Projects.Find(id);

            List<Projects> rlist = null;

            if (projects == null) {
                return HttpNotFound();
            }

            if (projects != null) {
                ViewBag.Type = "project";
            }

            return View(projects);
        }

        // POST: /Project/ProjectsEdit/5
        [HttpPost]
        public ActionResult ProjectsEdit(Projects projects) {
            if (ModelState.IsValid) {
                db.Entry(projects).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Projects");
            }

            return View(projects);
        }

        // GET: /Admin/ProjectsDelete
        public ActionResult ProjectsDelete(int id = 0) {
            Projects projects = db.Projects.Find(id);
            if (projects == null) {
                return HttpNotFound();
            }
            else {
                db.Projects.Remove(projects);
                db.SaveChanges();
                return RedirectToAction("Projects");
            }

            return View(projects);
        }

        // POST: /Admin/ProjectsDelete
        [HttpPost, ActionName("ProjectsDelete")]
        [ValidateAntiForgeryToken]
        public ActionResult ProjectsConfDelete(int id) {
            Projects projects = db.Projects.Find(id);
            db.Projects.Remove(projects);
            db.SaveChanges();
            return RedirectToAction("Projects");
        }

        public ActionResult HoursBreakDown(int Id = 0) {
            WorkGroupPercentage model = new WorkGroupPercentage();

            WorkGroupPercentage percentageexist = (from e in db.WorkGroupPercentages
                                                   where e.ProjectId == Id
                                                   select e).First();

            if (percentageexist != null) {
                model.Design = percentageexist.Design;
                model.Dev = percentageexist.Dev;
                model.Docs = percentageexist.Docs;
                model.EM = percentageexist.EM;
                model.Peerreview = percentageexist.Peerreview;
                model.ProjMgmt = percentageexist.ProjMgmt;
                model.Req = percentageexist.Req;
                model.SIT = percentageexist.SIT;
                model.TurnSupport = percentageexist.TurnSupport;
                model.UAT = percentageexist.UAT;
                model.UnitTest = percentageexist.UnitTest;
                model.Warranty = percentageexist.Warranty;
                model.WorkGroupId = percentageexist.WorkGroupId;
            }
            model.ProjectId = Id;
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult HoursBreakDown(WorkGroupPercentage percentage, int Id = 0) {
            percentage.ProjectId = Id;
            var teamid = (from pt in db.Projects
                          join TeamOnProject p in db.TeamOnProject on pt.ProjectId equals p.ProjectId into temp
                          from p in temp.DefaultIfEmpty()
                          where pt.ProjectId == Id
                          select new { p.TeamId }).First();

            percentage.TeamId = teamid.TeamId;
            db.WorkGroupPercentages.Add(percentage);
            db.SaveChanges();


            return RedirectToAction("Projects");
        }
    }
}